def myadd(a,b):
    return a+b

def mysub(a,b):
    return a-b
